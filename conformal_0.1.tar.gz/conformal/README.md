conformal: an R package to calculate prediction errors in the conformal prediction framework

Object-oriented programming (OOP) implementation 
of conformal prediction using reference classes.
Prediction errors for regression (confidence regions)
and for classification (p.values)
can be computed in the conformal prediction framework.
See the package documentation for further details.

To install conformal type, "R CMD install conformal"



